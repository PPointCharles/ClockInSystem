import request from '@/utils/request'

// 查询工具检查列表
export function listCheck(query) {
  return request({
    url: '/toolcheck/check/list',
    method: 'get',
    params: query
  })
}

// 查询树状工具列表
export function listCheckForTree(query){
  return request({
    url: '/toolcheck/check/list',
    method: 'get',
    params: query
  })
}


// 查询工具检查详细
export function getCheck(id) {
  return request({
    url: '/toolcheck/check/' + id,
    method: 'get'
  })
}

// 新增工具检查
export function addCheck(data) {
  return request({
    url: '/toolcheck/check',
    method: 'post',
    data: data
  })
}

// 修改工具检查
export function updateCheck(data) {
  return request({
    url: '/toolcheck/check',
    method: 'put',
    data: data
  })
}

// 删除工具检查
export function delCheck(id) {
  return request({
    url: '/toolcheck/check/' + id,
    method: 'delete'
  })
}
