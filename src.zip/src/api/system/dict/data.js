import request from '@/utils/request'

// 查询字典数据列表
export function listData(query) {
  return request({
    url: '/system/dict/data/list',
    method: 'get',
    params: query
  })
}

// 查询字典数据详细
export function getData(dictCode) {
  return request({
    url: '/system/dict/data/' + dictCode,
    method: 'get'
  })
}

// 根据字典类型查询字典数据信息
export function getDicts(dictType) {
  return request({
    url: '/system/dict/data/type/' + dictType,
    method: 'get'
  })
}

// 根据输入的字典类型查找对应的字典@hzc
export function getDictByType(dictType){
  return request({
    url: '/system/dict/data/type/' + dictType,
    method: 'get'
  }).then(
      data => {
        // for(each in data.data){
        //   console.log(each);
        // }
        var obj = [];
        for(var i=0,len=data.data.length;i<len;i++){
          obj.push(data.data[i].dictValue)
        }
        return obj;
      }
  );
  // console.log(a);
}

// 根据输入的项目名获取对象对应的字典




// 新增字典数据
export function addData(data) {
  return request({
    url: '/system/dict/data',
    method: 'post',
    data: data
  })
}

// 修改字典数据
export function updateData(data) {
  return request({
    url: '/system/dict/data',
    method: 'put',
    data: data
  })
}

// 删除字典数据
export function delData(dictCode) {
  return request({
    url: '/system/dict/data/' + dictCode,
    method: 'delete'
  })
}
