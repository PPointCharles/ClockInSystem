<template>
  <div class="app-container">
    <el-form
      :model="queryParams"
      ref="queryForm"
      :inline="true"
      v-show="showSearch"
      label-width="68px"
    >
      <el-form-item label="项目名称" prop="testProject">
        <el-input
          v-model="queryParams.testProject"
          placeholder="请输入项目名称"
          clearable
          size="small"
          @keyup.enter.native="handleQuery"
        />
      </el-form-item>
      <el-form-item label="工具类型" prop="toolType">
        <el-select
          v-model="queryParams.toolType"
          placeholder="请选择工具类型"
          clearable
          size="small"
        >
          <el-option
            v-for="dict in dict.type.testItem"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="工具子类型" prop="toolSubType">
        <el-input
          v-model="queryParams.toolSubType"
          placeholder="请输入工具子类型"
          clearable
          @keyup.enter.native="handleQuery"
          style="width=100px"
        />
      </el-form-item>
      <el-form-item label="工具状态" prop="status">
        <el-select
          v-model="queryParams.status"
          placeholder="请选择工具状态"
          clearable
          size="small"
        >
          <el-option
            v-for="dict in dict.type.status"
            :key="dict.value"
            :label="dict.label"
            :value="dict.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button
          type="primary"
          icon="el-icon-search"
          size="mini"
          @click="handleQuery"
          >搜索</el-button
        >
        <el-button icon="el-icon-refresh" size="mini" @click="resetQuery"
          >重置</el-button
        >
      </el-form-item>
    </el-form>

    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="el-icon-plus"
          size="mini"
          @click="handleAdd"
          v-hasPermi="['toolcheck:check:add']"
          >新增</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-edit"
          size="mini"
          :disabled="single"
          @click="handleUpdate"
          v-hasPermi="['toolcheck:check:edit']"
          >修改</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="el-icon-delete"
          size="mini"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['toolcheck:check:remove']"
          >删除</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="warning"
          plain
          icon="el-icon-download"
          size="mini"
          @click="handleExport"
          v-hasPermi="['toolcheck:check:export']"
          >导出</el-button
        >
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="success"
          plain
          icon="el-icon-s-data"
          size="mini"
          @click="handleSummary"
          >项目总览</el-button
        >
      </el-col>
      <right-toolbar
        :showSearch.sync="showSearch"
        @queryTable="getList"
      ></right-toolbar>
    </el-row>

    <!-- 折叠面板 -->
    <el-collapse
      v-model="activeNames"
      @change="handleChange"
      v-for="(item, index) in checkList1"
      :key="index"
    >
      <el-collapse-item :title="item.proj" :name="item.proj">
        <template slot="title">
          <h2>{{ item.proj }}</h2>
        </template>
        <div>
        <el-table
          v-loading="loading"
          :data="item.items"
          @selection-change="handleSelectionChange"
          border
          :row-class-name="tableRowClassName"
        >
          <el-table-column type="selection" width="55" align="center" />
          <el-table-column label="工具ID" align="center" prop="id" />
          <el-table-column label="项目名称" align="center" prop="testProject" />
          <el-table-column label="工具类型" align="center" prop="toolType">
            <template slot-scope="scope">
              <dict-tag
                :options="dict.type.testItem"
                :value="scope.row.toolType"
              />
            </template>
          </el-table-column>
          <el-table-column
            label="工具子类型"
            align="center"
            prop="toolSubType"
          />
          <el-table-column label="工具状态" align="center" prop="status">
            <template slot-scope="scope">
              <dict-tag :options="dict.type.status" :value="scope.row.status" />
            </template>
              
          </el-table-column>
          <el-table-column label="备注" align="center" prop="remark" />
          <el-table-column
            label="操作"
            align="center"
            class-name="small-padding fixed-width"
            fixed="right"
          >
            <template slot-scope="scope">
              <el-button
                size="mini"
                type="text"
                icon="el-icon-edit"
                @click="handleUpdate(scope.row)"
                v-hasPermi="['toolcheck:check:edit']"
                >修改</el-button
              >
              <el-button
                size="mini"
                type="text"
                icon="el-icon-delete"
                @click="handleDelete(scope.row)"
                v-hasPermi="['toolcheck:check:remove']"
                >删除</el-button
              >
            </template>
          </el-table-column>
        </el-table>
        <el-pagination
          background
          layout="prev, pager, next"
          :total="10"
          
          @pagination="getItemList1">
        </el-pagination>
        </div>
      </el-collapse-item>
    </el-collapse>

    <pagination
      v-show="total > 0"
      :total="total"
      :page.sync="queryParams.pageNum"
      :limit.sync="queryParams.pageSize"
      @pagination="getList"
    />

    <!-- 添加工具检查对话框 -->
    <el-dialog :title="title" :visible.sync="open" width="800px" append-to-body>
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="项目名称" prop="testProject">
          <el-input v-model="form.testProject" placeholder="请输入项目名称" />
        </el-form-item>
        <el-form-item label="工具类型" prop="toolType">
          <el-select
            v-model="form.toolType"
            placeholder="请选择工具类型"
            @change="toolTypeChange"
          >
            <el-option
              v-for="dict in dict.type.testItem"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>

        <!-- 分栏式测试 -->
        <el-row :gutter="20" style="margin-left: 30px">
          <el-col :span="6"
            ><p><strong>工具子类型</strong></p></el-col
          >
          <el-col :span="4"
            ><p><strong>工具状态</strong></p></el-col
          >
          <el-col :span="8"
            ><p><strong>备注</strong></p></el-col
          >
        </el-row>
        <el-row
          v-for="(item, index) in form.subTableData"
          :key="index"
          :gutter="20"
          style="margin-left: 30px"
        >
          <el-col :span="6">
            {{ item.subType }}
          </el-col>
          <el-col :span="4">
            <el-select placeholder="" v-model="item.status">
              <el-option
                v-for="dict in dict.type.status"
                :key="dict.value"
                :label="dict.label"
                :value="dict.value"
              ></el-option>
            </el-select>
          </el-col>
          <el-col :span="8">
            <el-input v-model="item.remark" placeholder="请输入备注信息" />
          </el-col>
        </el-row>

        <!-- 表格版本 -->
        <!-- <el-table border  style="width: 100%">
          <template v-for="(item, index) in form.subTableData">
            <el-table-column label="工具子类型"  width="180">
            </el-table-column>
            <el-table-column label="工具状态"  width="180">
              <el-select placeholder=""  >
                  <el-option
                    v-for="dict in dict.type.status"
                    :key="dict.value"
                    :label="dict.label"
                    :value="dict.value"
                  ></el-option>
                </el-select>
            </el-table-column>
            <el-table-column label="备注"> </el-table-column>         
          </template>

        </el-table> -->

        <!-- <el-table :data="subTableData"  stripe style="width: 100%">
          <el-table-column prop="toolSubType" label="工具子类型" width="180">
              
          </el-table-column>
          <el-table-column label="工具状态" width="180">
            
              <el-select  placeholder="">
                <el-option
                  v-for="dict in dict.type.status"
                  :key="dict.value"
                  :label="dict.label"
                  :value="dict.value"
                ></el-option>
              </el-select>
            
          </el-table-column>
          <el-table-column prop="remark" label="备注"> 
            
              <el-input v-model="form.remark" placeholder="请输入备注信息" />
            
          </el-table-column>
        </el-table> -->

        <!-- <el-form-item label="工具子类型" prop="toolSubType">
          <el-input v-model="form.toolSubType" placeholder="请输入工具子类型" />
        </el-form-item>
        <el-form-item label="工具状态" prop="status">
          <el-select v-model="form.status" placeholder="请选择工具状态">
            <el-option
              v-for="dict in dict.type.status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" placeholder="请输入备注" />
        </el-form-item> -->
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 修改工具检查对话框 -->
    <el-dialog
      :title="title"
      :visible.sync="updateOpen"
      width="500px"
      append-to-body
    >
      <el-form ref="form" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="项目名称" prop="testProject">
          <el-input v-model="form.testProject" placeholder="请输入项目名称" />
        </el-form-item>
        <el-form-item label="工具类型" prop="toolType">
          <el-select v-model="form.toolType" placeholder="请选择工具类型">
            <el-option
              v-for="dict in dict.type.testItem"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="工具子类型" prop="toolSubType">
          <el-input v-model="form.toolSubType" placeholder="请输入工具子类型" />
        </el-form-item>
        <el-form-item label="工具状态" prop="status">
          <el-select v-model="form.status" placeholder="请选择工具状态">
            <el-option
              v-for="dict in dict.type.status"
              :key="dict.value"
              :label="dict.label"
              :value="dict.value"
            ></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="备注" prop="remark">
          <el-input v-model="form.remark" placeholder="请输入备注" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </el-dialog>

    <!-- 数据总览对话框 -->
    <el-dialog
      :title="title"
      :visible.sync="summaryOpen"
      width="500px"
      append-to-body
    >
      <el-table :data="summaryList" border style="width: 100%">
        <el-table-column prop="proj" label="项目名称" width="150">
        </el-table-column>
        <el-table-column prop="totalnum" label="评估项总数"> </el-table-column>
        <el-table-column prop="closenum" label="关闭数"> </el-table-column>
        <el-table-column prop="closerate" label="关闭率"> </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button type="primary" @click="cancel">关 闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {
  listCheck,
  getCheck,
  delCheck,
  addCheck,
  updateCheck,
} from "@/api/toolcheck/check";
import { getDicts } from "@/api/system/dict/data";

export default {
  name: "Check",
  dicts: ["status", "testItem"],
  data() {
    return {
      // 遮罩层
      loading: true,
      // 选中数组
      ids: [],
      // 非单个禁用
      single: true,
      // 非多个禁用
      multiple: true,
      // 显示搜索条件
      showSearch: true,
      // 总条数
      total: 0,
      // 工具检查表格数据
      checkList: [],
      checkListTree: [],
      summaryList: [],
      // 弹出层标题
      title: "",
      // 是否显示弹出层
      open: false,
      // 是否显示数据更新弹出层@hzc
      updateOpen: false,
      // 总览弹出层
      summaryOpen: false,
      // 可折叠面板
      activeNames: ["1"],
      // 检查项列表
      subTableData: [],
      activeNames: ["1"],

      treeIndent: 20,
      checkList1: [],

      // 查询参数
      queryParams: {
        pageNum: 1,
        pageSize: 10,
        testProject: null,
        toolType: null,
        toolSubType: null,
        status: null,
      },
      // 表单参数
      form: {
        subTableData: [],
      },
      // 表单校验
      rules: {
        testProject: [
          { required: true, message: "项目名称不能为空", trigger: "blur" },
        ],
        toolType: [
          { required: true, message: "工具类型不能为空", trigger: "change" },
        ],
      },
      spanArr: [],
      toolTypeSpanArr: [],
      position: 0,
      toolTypePosition: 0,
    };
  },
  created() {
    this.getList();
  },
  // computed: {
  //   form:{
  //     subType: function(){
  //       return this.form.subTableData.subType;
  //     }
  //   }
  // },
  methods: {
    // 合并表格
    // checklistSpanMethod({row, column, rowIndex, columnIndex}){
    //   if(columnIndex === 2){
    //     // if(row.toolType != )
    //     console.log(this.checkList);
    //     // console.log(this.checkList[rowIndex+1].toolType);
    //     console.log(row.toolType);
    //     if(rowIndex < (this.checkList.length-1)){
    //       if(this.checkList[rowIndex+1].toolType !== row.toolType){
    //         return [2,1];
    //       }
    //     }
    //   }else{
    //     return [0,0];
    //   }
    // },

    //生成总结表
    handleSummary() {
      this.summaryOpen = true;
      this.summaryList.length = 0;
      this.checkListTree.forEach((item, index) => {
        var proj = item.testProject;
        var closeNum = 0;
        var closeRate = 0;
        var openNum = 0;
        if (item.status === "开启") {
          openNum += 1;
        } else {
          closeNum += 1;
        }

        for (var i = 0, len = item.children.length; i < len; i++) {
          if (item.children[i].status === "开启") {
            openNum += 1;
          } else {
            closeNum += 1;
          }
        }
        closeRate =
          Math.round((closeNum / (openNum + closeNum)) * 100) > 0
            ? Math.round((closeNum / (openNum + closeNum)) * 100) + "%"
            : 0;
        this.summaryList.push({
          proj: proj,
          totalnum: closeNum + openNum,
          closenum: closeNum,
          closerate: closeRate,
        });
      });
    },

    getItemList(){
      return this.checkList1[0].items;
    },

    //生成树状表格
    listToTreeTable() {
      var arr1 = [];
      var p1 = 0;
      this.checkListTree = [];
      this.checkList.forEach((item, index) => {
        this.checkList[index].children = [];
        if (index === 0) {
          this.checkListTree.push(this.checkList[index]);
          arr1.push(1);
          p1 = 0;
        } else {
          if (
            this.checkList[index].testProject ===
            this.checkList[index - 1].testProject
          ) {
            this.checkListTree[p1].children.push(this.checkList[index]);
            arr1[p1] += 1;
            arr1.push(0);
          } else {
            this.checkListTree.push(this.checkList[index]);
            arr1.push(1);
            p1 += 1;
          }
        }
      });
    },

    // getchecklist1
    getCheckList1() {
      var p1 = 0;
      this.checkList1.length = 0;
      this.checkList.forEach((item, index) => {
        if (index === 0) {
          this.checkList1.push({
            proj: item.testProject,
            items: [item],
          });
        } else {
          if (item.testProject === this.checkList[index - 1].testProject) {
            this.checkList1[p1].items.push(item);
          } else {
            this.checkList1.push({
              proj: item.testProject,
              items: [item],
            });
            p1 += 1;
          }
        }
      });
    },

    tableRowClassName({ row, rowIndex }) {
      if (row.status === "开启") {
        return "fail-row";
      }
      return "";
    },

    // 合并单元格
    rowspan() {
      this.checkList.forEach((item, index) => {
        if (index === 0) {
          this.spanArr.push(1);
          this.position = 0;
          this.toolTypeSpanArr.push(1);
          this.toolTypePosition = 0;
        } else {
          if (
            this.checkList[index].testProject ===
            this.checkList[index - 1].testProject
          ) {
            this.spanArr[this.position] += 1;
            this.spanArr.push(0);
          } else {
            this.spanArr.push(1);
            this.position = index;
          }
          if (
            this.checkList[index].toolType ===
            this.checkList[index - 1].toolType
          ) {
            this.toolTypeSpanArr[this.toolTypePosition] += 1;
            this.toolTypeSpanArr.push(0);
          } else {
            this.toolTypeSpanArr.push(1);
            this.toolTypePosition = index;
          }
        }
      });
    },
    // 表格合并
    objectSpanMethod({ row, column, rowIndex, columnIndex }) {
      if (columnIndex === 2) {
        const _row = this.spanArr[rowIndex];
        const _col = _row > 0 ? 1 : 0;
        return {
          rowspan: _row,
          colspan: _col,
        };
      }
      if (columnIndex === 3) {
        const _row_ = this.toolTypeSpanArr[rowIndex];
        const _col_ = _row_ > 0 ? 1 : 0;
        return {
          rowspan: _row_,
          colspan: _col_,
        };
      }
    },

    //切换type时生成对应的subtype
    toolTypeChange(id) {
      getDicts(id).then((data) => {
        this.form.subTableData.splice(0);
        // for (var i = 0, len = data.data.length; i < len; i++) {
        //   this.form.subTableData.push({
        //     subType: data.data[i].dictValue,
        //   });
        // }
        data.data.forEach(element => {
          this.form.subTableData.push({
            subType: element.dictValue
          })
        })
      });
    },
    //可折叠面板
    handleChange(val) {
      console.log(val);
    },

    /** 查询工具检查列表 */
    getList() {
      this.loading = true;
      listCheck(this.queryParams).then((response) => {
        this.checkList = response.rows;
        this.total = response.total;
        this.loading = false;

        // 初始化单元格合并信息
        this.position = 0;
        this.toolTypePosition = 0;
        this.spanArr.length = 0;
        this.toolTypeSpanArr.length = 0;
        this.rowspan(); //获取单元格合并信息@hzc
        this.listToTreeTable(); // @hzc
        this.getCheckList1(); //@hzc
      });
    },
    // 取消按钮
    cancel() {
      this.open = false;
      this.updateOpen = false;
      this.summaryOpen = false;
      this.reset();
    },
    // 表单重置
    reset() {
      this.form = {
        id: null,
        testProject: null,
        toolType: null,
        toolSubType: null,
        status: null,
        createBy: null,
        createTime: null,
        updateBy: null,
        updateTime: null,
        remark: null,
        subTableData: [],
      };
      this.resetForm("form");
    },
    /** 搜索按钮操作 */
    handleQuery() {
      this.queryParams.pageNum = 1;
      this.getList();
    },
    /** 重置按钮操作 */
    resetQuery() {
      this.resetForm("queryForm");
      this.handleQuery();
    },
    // 多选框选中数据
    handleSelectionChange(selection) {
      this.ids = selection.map((item) => item.id);
      this.single = selection.length !== 1;
      this.multiple = !selection.length;
    },
    /** 新增按钮操作 */
    handleAdd() {
      this.reset();
      this.open = true;
      this.title = "添加工具检查";
    },
    /** 修改按钮操作 */
    handleUpdate(row) {
      this.reset();
      const id = row.id || this.ids;
      getCheck(id).then((response) => {
        this.form = response.data;
        this.updateOpen = true;
        this.title = "修改工具检查";
      });
    },
    /** 提交按钮 */
    submitForm() {
      this.$refs["form"].validate((valid) => {
        console.log('valid' + valid);
        if (valid) {
          if (this.form.id != null) {
            updateCheck(this.form).then((response) => {
              this.$modal.msgSuccess("修改成功");
              this.updateOpen = false;
              this.getList();
            });
          } else {
            // for (var i = 0, len = this.form.subTableData.length; i < len; i++) {
            //   this.form.toolSubType = this.form.subTableData[i].subType;
            //   this.form.status = this.form.subTableData[i].status;
            //   this.form.remark = this.form.subTableData[i].remark;
            //   addCheck(this.form).then((response) => {
            //     this.$modal.msgSuccess("新增成功");
            //     this.open = false;
            //     this.getList();
            //   });
            // }
            this.form.subTableData.forEach(element => {
              this.form.toolSubType = element.subType;
              this.form.status = element.status;
              this.form.remark = element.remark;
              addCheck(this.form).then((response) => {
                this.$modal.msgSuccess("新增成功");
                this.open = false;
                this.getList();
              });
            })
            
          }
        }
      });
    },
    /** 删除按钮操作 */
    handleDelete(row) {
      const ids = row.id || this.ids;
      this.$modal
        .confirm('是否确认删除工具检查编号为"' + ids + '"的数据项？')
        .then(function () {
          return delCheck(ids);
        })
        .then(() => {
          this.getList();
          this.$modal.msgSuccess("删除成功");
        })
        .catch(() => {});
    },
    /** 导出按钮操作 */
    handleExport() {
      this.download(
        "toolcheck/check/export",
        {
          ...this.queryParams,
        },
        `check_${new Date().getTime()}.xlsx`
      );
    },
  },
};
</script>

<style >
.el-col {
  border-radius: 4px;
}

.grid-content {
  border-radius: 4px;
  min-height: 36px;
  /* text-align:center; 
    vertical-align:middle; */
}
.row-bg {
  padding: 10px 0;
  /* background-color: #f9fafc; */
}

.el-table .fail-row {
  background: oldlace;
}
</style>